package com.example.stopwatch;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView tvTimer;
    private Button btnStartPause, btnReset;
    private boolean isRunning = false;
    private int milliseconds = 0;

    private Handler handler = new Handler();
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            milliseconds += 10;
            int seconds = (milliseconds / 1000) % 60;
            int minutes = (milliseconds / 1000) / 60;
            int millis = milliseconds % 1000;
            tvTimer.setText(String.format("%02d:%02d:%03d", minutes, seconds, millis));
            handler.postDelayed(this, 10);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTimer = findViewById(R.id.tvTimer);
        btnStartPause = findViewById(R.id.btnStartPause);
        btnReset = findViewById(R.id.btnReset);

        btnStartPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isRunning) {
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });

        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });
    }

    private void startTimer() {
        btnStartPause.setText("Pause");
        isRunning = true;
        handler.postDelayed(runnable, 10);
    }

    private void pauseTimer() {
        btnStartPause.setText("Start");
        isRunning = false;
        handler.removeCallbacks(runnable);
    }

    private void resetTimer() {
        btnStartPause.setText("Start");
        isRunning = false;
        milliseconds = 0;
        tvTimer.setText("00:00:00");
        handler.removeCallbacks(runnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }
}
